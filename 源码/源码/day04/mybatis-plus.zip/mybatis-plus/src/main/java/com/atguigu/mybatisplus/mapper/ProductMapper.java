package com.atguigu.mybatisplus.mapper;

import com.atguigu.mybatisplus.entity.Product;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface ProductMapper extends BaseMapper<Product> {
}
