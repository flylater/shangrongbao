// export let star = '王力宏'

// export function sing(title) {
//   console.log(title)
// }

//第二种导出模块的方法
let star = '王力宏'

function sing(title) {
  console.log(title)
}

export { star, sing }
