export let star = 5
