export default {
  username: 'helen',
  age: 20,
  coding() {
    console.log('hello world')
  },
}
