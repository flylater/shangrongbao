let star = '周杰伦'
