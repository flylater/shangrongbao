// function fn(a){
//   return a + 100
// }

// let fn = function (a) {
//   return a + 100
// }

// let fn = (a) => {
//   return a + 100
// }

let fn = (a) => a + 100

let result = fn(1)
console.log(result)
