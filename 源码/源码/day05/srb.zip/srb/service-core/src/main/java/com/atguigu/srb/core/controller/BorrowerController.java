package com.atguigu.srb.core.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 借款人 前端控制器
 * </p>
 *
 * @author Helen
 * @since 2021-02-20
 */
@RestController
@RequestMapping("/borrower")
public class BorrowerController {

}

