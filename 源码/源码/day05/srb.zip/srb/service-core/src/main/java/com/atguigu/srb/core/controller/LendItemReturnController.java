package com.atguigu.srb.core.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 标的出借回款记录表 前端控制器
 * </p>
 *
 * @author Helen
 * @since 2021-02-20
 */
@RestController
@RequestMapping("/lendItemReturn")
public class LendItemReturnController {

}

